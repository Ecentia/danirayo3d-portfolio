'use client';

import { useEffect, useState } from 'react';
import Masonry from 'react-masonry-css';
import { supabase } from '@/lib/supabase';
import { Project } from '@/types/database';
import ProjectCard from '../projects/ProjectCard';
import ProjectModal from '../projects/ProjectModal';
import { Plus, Trash2, LayoutGrid } from 'lucide-react';
import { useAdmin } from '@/context/AdminContext';
import { useLanguage } from '@/context/LanguageContext';
import { motion, AnimatePresence } from 'framer-motion';

const breakpointColumnsObj = {
  default: 4,
  1100: 3,
  768: 2,
  500: 1
};

export default function ProjectsGrid() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const { isAdmin, deleteProject, isSaving } = useAdmin();
  const { isSpanish } = useLanguage();

  const fetchProjects = async () => {
    const { data } = await supabase
      .from('projects')
      .select('*')
      .order('display_order', { ascending: true });
    if (data) setProjects(data);
  };

  // Se ejecuta al cargar la página y automáticamente después de darle a Guardar
useEffect(() => { 
  // Cuando isSaving vuelve a ser 'false' (termina de guardar), recargamos los proyectos
  if (!isSaving) {
    fetchProjects(); 
  }
}, [isSaving]);

  const handleOpenCreate = () => {
    setSelectedProjectId(null);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (id: string) => {
    setSelectedProjectId(id);
    setIsModalOpen(true);
  };

  const handleDeleteClick = async (e: React.MouseEvent, projectId: string) => {
    e.stopPropagation();
    await deleteProject(projectId);
    fetchProjects();
  };

  return (
    // CAMBIO: bg-black -> bg-transparent para dejar ver el fondo del Layout
    <section className="py-24 bg-transparent relative z-10 overflow-hidden">
      <div className="max-w-[1600px] mx-auto px-6 md:px-12">
        
        {/* CABECERA DE SECCIÓN TÉCNICA */}
        <div className="flex flex-col mb-16">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-[1px] bg-yellow-500"></div>
            <span className="text-yellow-500 font-bold text-[10px] tracking-[0.5em] uppercase flex items-center gap-2">
               <LayoutGrid size={12} /> {isSpanish ? "Galería_de_Proyectos" : "Projects_Gallery"}
            </span>
          </div>
          <h2 className="text-5xl md:text-7xl font-black text-white tracking-tighter uppercase">
            {isSpanish ? (
              <>
                Selección <span className="text-white/20">Visual</span>
              </>
            ) : (
              <>
                Visual <span className="text-white/20">Selection</span>
              </>
            )}
          </h2>
        </div>

        <Masonry 
          breakpointCols={breakpointColumnsObj} 
          className="flex w-auto -ml-6" 
          columnClassName="pl-6 bg-clip-padding"
        >
         {/* BOTÓN AÑADIR (ADMIN) - ESTILO GLASS */}
          {isAdmin && (
            <motion.div 
              key="admin-add-btn" /* <--- ¡ESTA ES LA LÍNEA CLAVE! */
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-6"
            >
              <button 
                onClick={handleOpenCreate}
                className="w-full aspect-square border border-white/10 bg-white/5 backdrop-blur-md rounded-sm flex flex-col items-center justify-center gap-4 hover:border-yellow-500/50 hover:bg-white/10 transition-all group relative overflow-hidden"
              >
                {/* Micro-esquinas tácticas */}
                <div className="absolute top-0 left-0 w-2 h-2 border-t border-l border-yellow-500 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                <div className="absolute bottom-0 right-0 w-2 h-2 border-b border-r border-yellow-500 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                
                <div className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center text-white group-hover:bg-yellow-500 group-hover:border-yellow-500 transition-all duration-500">
                  <Plus size={24} />
                </div>
                <span className="font-mono text-[9px] tracking-[0.3em] text-zinc-500 group-hover:text-white uppercase transition-colors">
                  NEW_ENTITY
                </span>
              </button>
            </motion.div>
          )}

          {/* LISTA DE PROYECTOS DIRECTAMENTE COMO HIJOS */}
          {projects.map((project, index) => (
            <motion.div 
              key={project.id}
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              /* Quitamos el exit={{...}} porque ya no usamos AnimatePresence aquí */
              transition={{ duration: 0.4, delay: index * 0.05 }}
              className="relative group mb-6"
            >
              {/* Botón Borrar Minimalista */}
              {isAdmin && (
                  <button 
                      onClick={(e) => handleDeleteClick(e, project.id)}
                      className="absolute top-4 right-4 z-50 bg-black/60 backdrop-blur-md text-white/50 p-2 border border-white/10 rounded-sm opacity-0 group-hover:opacity-100 transition-all hover:text-red-500 hover:border-red-500"
                      title="Eliminar Proyecto"
                  >
                      <Trash2 size={14} />
                  </button>
              )}
              
              <div className="transform transition-transform duration-700 group-hover:translate-y-[-4px]">
                <ProjectCard 
                  project={project} 
                  onClick={() => handleOpenEdit(project.id)}
                />
              </div>
            </motion.div>
          ))}
        </Masonry>

        {/* MODAL DE EDICIÓN */}
        <ProjectModal 
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          initialProjectId={selectedProjectId}
          allProjectsList={projects}
        />
      </div>
    </section>
  );
}